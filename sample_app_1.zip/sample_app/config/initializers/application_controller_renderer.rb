# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '52b2a7deed977211f9f2d8f65be4670e791c4e8b9140d103822858cb8e25c3b47da9d5bcb97ebe67eaebea435b9af1e5bb0703927ad669b528bdacf4b7abf8eb'